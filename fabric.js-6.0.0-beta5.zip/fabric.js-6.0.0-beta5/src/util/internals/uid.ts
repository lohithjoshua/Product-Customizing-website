let id = 0;

export const uid = () => id++;
