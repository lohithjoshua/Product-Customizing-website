# Security Policy

## Reporting a Vulnerability

Please report security issues to `andreabogazzi79@gmail.com`
